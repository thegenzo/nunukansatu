<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nunukan Satu - Kantor Daring</title>

    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;600;700&display=swap" rel="stylesheet">

    <!-- Custom CSS -->
    <link rel="stylesheet" href="{{ asset('web-assets/style.css')}}">

    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
</head>

<body>

    <!-- Main Background -->
    <div class="main-background"></div>

    <!-- Header / Navbar -->
    <nav class="navbar fixed-top mt-4">
        <div class="container d-flex justify-content-center">
            <div
                class="floating-nav bg-white rounded-pill px-4 py-2 shadow-sm d-flex align-items-center justify-content-between">
                <!-- Logo Area -->
                <div class="d-flex align-items-center gap-2">
                    <img src="{{ asset('web-assets/assets/img/Nunukansatu Logo1 2.png') }}" alt="Nunukan Satu Logo"
                        height="40">
                </div>

                <!-- Search Button -->
                <div class="ms-5">
                    <button id="searchBtn"
                        class="btn btn-primary-red rounded-3 px-4 py-2 d-flex align-items-center gap-2">
                        <i class="bi bi-search"></i>
                        <span>Search</span>
                    </button>
                </div>
            </div>
        </div>
    </nav>

    <!-- Main Content / Central Button -->
    <main class="container-fluid d-flex justify-content-center align-items-center"
        style="height: 100vh; pointer-events: none;">
        <!-- Central Diamond Button -->
        <div class="central-button-container" style="pointer-events: auto;">
            <div class="diamond-menu-area">
                <!-- Hidden Menu Buttons -->
                <a href="#" class="menu-btn btn-top" id="administrasi-pemerintah">
                    <img src="{{ asset('web-assets/assets/img/ADM Pemerintah Button 1.png') }}" alt="ADM Pemerintah"
                        class="img-fluid">
                </a>
                <a href="#" class="menu-btn btn-left" id="layanan-publik">
                    <img src="{{ asset('web-assets/assets/img/Layanan Publik Button 1.png') }}" alt="Layanan Publik"
                        class="img-fluid">
                </a>
                <a href="{{ route('web.mall-data-informasi') }}" class="menu-btn btn-right">
                    <img src="{{ asset('web-assets/assets/img/Mall Data dan Informasi Button 1.png') }}"
                        alt="Mall Data dan Informasi" class="img-fluid">
                </a>

                <!-- Main Central Button -->
                <a href="#" class="btn-main-diamond d-block text-decoration-none">
                    <img src="{{ asset('web-assets/assets/img/Main Button Flat 1.png') }}" alt="Nunukan Satu"
                        class="img-fluid main-logo-img">
                </a>
            </div>
        </div>
    </main>

    <!-- Footer -->
    <footer class="fixed-bottom bg-white py-3 border-top">
        <div class="container-fluid px-5 d-flex justify-content-between align-items-center">
            <!-- Left: Logo/Icon -->
            <div class="d-flex align-items-center gap-2 footer-logo-section">
                <img src="{{ asset('web-assets/assets/img/Footer 3.png') }}" alt="Nunukan Satu Footer Logo" height="40">
                <img src="{{ asset('web-assets/assets/img/Nunukansatu Logo1 2.png') }}" alt="Nunukan Satu Logo"
                    height="40">
            </div>

            <!-- Center: Copyright -->
            <div class="text-center">
                <small class="fw-bold text-uppercase" style="font-size: 0.7rem; letter-spacing: 1px;">&copy; 2026
                    PEMERINTAH KABUPATEN NUNUKAN. ALL RIGHTS RESERVED.</small>
            </div>

            <!-- Right: Pengaduan Button -->
            <div class="d-flex">
                <button class="btn btn-outline-danger px-4 py-1 d-flex align-items-center gap-2"
                    style="border-radius: 10px;">
                    <i class="bi bi-chevron-up"></i>
                    <span>Pengaduan</span>
                </button>
                <img src="{{ asset('web-assets/assets/img/Footer 2.png') }}" alt="Nunukan Satu Footer Logo" height="40">
            </div>
        </div>
    </footer>

    <!-- Floating Live Chat Button -->
    <div class="position-fixed bottom-0 end-0 m-4 mb-5 pb-4" style="z-index: 1050;">
        <button id="liveChatBtn"
            class="btn btn-primary-red rounded-circle shadow-lg d-flex align-items-center justify-content-center"
            style="width: 60px; height: 60px;">
            <i class="bi bi-headset fs-3"></i>
        </button>
    </div>

    <!-- Live Chat Modal -->
    <div id="liveChatModal" class="modal-overlay live-chat-modal-overlay">
        <div class="modal-content live-chat-modal-content">
            <!-- Header with Logo -->
            <div class="live-chat-header">
                <div class="live-chat-logo-container">
                    <img src="{{ asset('web-assets/assets/img/Nunukansatu Logo1 2.png') }}" alt="Nunukan Satu"
                        class="live-chat-logo">
                </div>
            </div>

            <!-- Content Area -->
            <div class="live-chat-body">
                <!-- Greeting Message -->
                <div class="live-chat-greeting">
                    <h3>Hai</h3>
                    <p>Bagaimana kami dapat membantu?</p>
                </div>

                <!-- Form Fields -->
                <form id="liveChatForm" class="live-chat-form">
                    <!-- Email Field -->
                    <div class="live-chat-field">
                        <label for="chatEmail" class="live-chat-label">Email</label>
                        <input type="email" id="chatEmail" class="live-chat-input"
                            placeholder="Masukkan alamat email Anda" required>
                    </div>

                    <!-- Name Field -->
                    <div class="live-chat-field">
                        <label for="chatName" class="live-chat-label">Nama</label>
                        <input type="text" id="chatName" class="live-chat-input"
                            placeholder="Masukkan nama lengkap Anda" required>
                    </div>

                    <!-- Message Field -->
                    <div class="live-chat-field live-chat-field-large">
                        <label for="chatMessage" class="live-chat-label">Pesan</label>
                        <textarea id="chatMessage" class="live-chat-textarea" placeholder="Masukkan pesan Anda"
                            required></textarea>
                    </div>

                    <!-- Submit Button -->
                    <button type="submit" class="live-chat-submit-btn">
                        Start Conversation
                    </button>
                </form>
            </div>

            <!-- Close Button -->
            <button class="close-modal btn btn-sm btn-danger live-chat-close"
                style="position: absolute; top: 10px; right: 10px; z-index: 10;">
                <i class="bi bi-x"></i>
            </button>
        </div>
    </div>

    <!-- Layanan Publik Modal -->
    <div id="publicModal" class="modal-overlay">
        <div class="modal-content modal-public-services">
            <div class="modal-header-public">
                <div class="header-title-section">
                    <h2>LAYANAN PUBLIK</h2>
                    <div class="header-underline"></div>
                </div>
                <button class="close-modal btn btn-sm btn-danger px-3">
                    <i class="bi bi-x"></i>
                    <span>Keluar</span>
                </button>
            </div>
            <div class="modal-body-public">
                <div class="service-grid-new">
                    <!-- Row 1 -->
                    <!-- Card 1: Layanan Pengaduan -->
                    <div class="service-card-new">
                        <div class="card-image-section">
                            <img src="{{ asset('web-assets/assets/img/public-service-card-header.png') }}"
                                alt="Layanan Pengaduan" class="card-bg-image">
                            <div class="card-overlay"></div>
                            <h3 class="card-title">Layanan Pengaduan</h3>
                        </div>
                        <div class="card-content-section">
                            <div class="service-btn-group">
                                <a href="{{ route('web.public-services', ['url' => 'https://lapor.go.id/', 'name' => 'LAPOR!']) }}"
                                    class="service-btn">
                                    <span class="btn-icon">
                                        <img src="{{ asset('web-assets/assets/img/icon-lapor.png') }}" alt="LAPOR!">
                                    </span>
                                    <span class="btn-text">LAPOR!</span>
                                </a>
                                <a href="{{ route('web.public-services', ['url' => 'https://satpolpp.nunukankab.go.id/', 'name' => 'SILAPDAT']) }}"
                                    class="service-btn">
                                    <span class="btn-icon">
                                        <img src="{{ asset('web-assets/assets/img/icon-silapdat.png') }}"
                                            alt="SILAPDAT">
                                    </span>
                                    <span class="btn-text">SILAPDAT</span>
                                </a>
                            </div>
                        </div>
                    </div>

                    <!-- Card 2: Layanan Hukum -->
                    <div class="service-card-new">
                        <div class="card-image-section">
                            <img src="{{ asset('web-assets/assets/img/public-service-card-header.png') }}"
                                alt="Layanan Hukum" class="card-bg-image">
                            <div class="card-overlay"></div>
                            <h3 class="card-title">Layanan Hukum</h3>
                        </div>
                        <div class="card-content-section">
                            <div class="service-btn-group">
                                <a href="{{ route('web.public-services', ['url' => 'https://jdih.nunukankab.go.id/', 'name' => 'JDIH']) }}"
                                    class="service-btn">
                                    <span class="btn-icon">
                                        <img src="{{ asset('web-assets/assets/img/icon-jdih.png') }}" alt="JDIH">
                                    </span>
                                    <span class="btn-text">JDIH</span>
                                </a>
                                <a href="{{ route('web.public-services', ['url' => 'https://jdihsetwan.nunukankab.go.id/', 'name' => 'JDIH Setwan']) }}"
                                    class="service-btn">
                                    <span class="btn-icon">
                                        <img src="{{ asset('web-assets/assets/img/icon-jdih.png') }}" alt="JDIH">
                                    </span>
                                    <span class="btn-text">JDIH Setwan</span>
                                </a>
                            </div>
                        </div>
                    </div>

                    <!-- Card 3: Layanan Sektor Pendidikan -->
                    <div class="service-card-new">
                        <div class="card-image-section">
                            <img src="{{ asset('web-assets/assets/img/public-service-card-header.png') }}"
                                alt="Layanan Sektor Pendidikan" class="card-bg-image">
                            <div class="card-overlay"></div>
                            <h3 class="card-title">Layanan Sektor<br>Pendidikan</h3>
                        </div>
                        <div class="card-content-section">
                            <div class="service-btn-group">
                                <a href="{{ route('web.public-services', ['url' => 'https://dapo.kemendikdasmen.go.id/', 'name' => 'DAPODIK']) }}"
                                    class="service-btn">
                                    <span class="btn-icon">
                                        <img src="{{ asset('web-assets/assets/img/icon-dapodik.png') }}" alt="DAPODIK">
                                    </span>
                                    <span class="btn-text">DAPODIK</span>
                                </a>
                            </div>
                        </div>
                    </div>

                    <!-- Card 4: Layanan Geospasial -->
                    <div class="service-card-new">
                        <div class="card-image-section">
                            <img src="{{ asset('web-assets/assets/img/public-service-card-header.png') }}"
                                alt="Layanan Geospasial" class="card-bg-image">
                            <div class="card-overlay"></div>
                            <h3 class="card-title">Layanan Geospasial</h3>
                        </div>
                        <div class="card-content-section">
                            <div class="service-btn-group">
                                <a href="{{ route('web.public-services', ['url' => 'https://gis.nunukankab.go.id/', 'name' => 'GIS KAB. NUNUKAN']) }}"
                                    class="service-btn">
                                    <span class="btn-icon">
                                        <img src="{{ asset('web-assets/assets/img/icon-gis-nunukan.png') }}"
                                            alt="GIS Kabupaten Nunukan">
                                    </span>
                                    <span class="btn-text">GIS KAB. NUNUKAN</span>
                                </a>
                            </div>
                        </div>
                    </div>

                    <!-- Row 2 -->
                    <!-- Card 5: Layanan Informasi & Dokumentasi -->
                    <div class="service-card-new">
                        <div class="card-image-section">
                            <img src="{{ asset('web-assets/assets/img/public-service-card-header.png') }}"
                                alt="Layanan Informasi & Dokumentasi" class="card-bg-image">
                            <div class="card-overlay"></div>
                            <h3 class="card-title">Layanan Informasi<br>& Dokumentasi</h3>
                        </div>
                        <div class="card-content-section">
                            <div class="service-btn-group">
                                <a href="{{ route('web.public-services', ['url' => 'http://ppid.nunukankab.go.id/', 'name' => 'PPID']) }}"
                                    class="service-btn">
                                    <span class="btn-icon">
                                        <img src="{{ asset('web-assets/assets/img/icon-ppid.png') }}" alt="PPID">
                                    </span>
                                    <span class="btn-text">PPID</span>
                                </a>
                            </div>
                        </div>
                    </div>

                    <!-- Card 6: Layanan Kependudukan -->
                    <div class="service-card-new">
                        <div class="card-image-section">
                            <img src="{{ asset('web-assets/assets/img/public-service-card-header.png') }}"
                                alt="Layanan Kependudukan" class="card-bg-image">
                            <div class="card-overlay"></div>
                            <h3 class="card-title">Layanan Kependudukan</h3>
                        </div>
                        <div class="card-content-section">
                            <div class="service-btn-group">
                                <a href="{{ route('web.public-services', ['url' => 'https://sipakrt.nunukankab.go.id/', 'name' => 'SIPAKRT']) }}"
                                    class="service-btn">
                                    <span class="btn-icon">
                                        <img src="{{ asset('web-assets/assets/img/icon-sipakrt.png') }}" alt="SIPAKRT">
                                    </span>
                                    <span class="btn-text">SIPAKRT</span>
                                </a>
                            </div>
                        </div>
                    </div>

                    <!-- Card 7: Layanan Pajak Retribusi -->
                    <div class="service-card-new">
                        <div class="card-image-section">
                            <img src="{{ asset('web-assets/assets/img/public-service-card-header.png') }}"
                                alt="Layanan Pajak Retribusi" class="card-bg-image">
                            <div class="card-overlay"></div>
                            <h3 class="card-title">Layanan Pajak<br>Retribusi</h3>
                        </div>
                        <div class="card-content-section">
                            <div class="service-btn-group">
                                <a href="{{ route('web.public-services', ['url' => 'https://pendapatan-nnk.id/', 'name' => 'BTH']) }}"
                                    class="service-btn">
                                    <span class="btn-icon">
                                        <img src="{{ asset('web-assets/assets/img/icon-bth.png') }}" alt="BTH">
                                    </span>
                                    <span class="btn-text">BTH</span>
                                </a>
                            </div>
                        </div>
                    </div>

                    <!-- Card 8: Layanan Berusaha -->
                    <div class="service-card-new">
                        <div class="card-image-section">
                            <img src="{{ asset('web-assets/assets/img/public-service-card-header.png') }}"
                                alt="Layanan Berusaha" class="card-bg-image">
                            <div class="card-overlay"></div>
                            <h3 class="card-title">Layanan Berusaha</h3>
                        </div>
                        <div class="card-content-section">
                            <div class="service-btn-group">
                                <a href="{{ route('web.public-services', ['url' => 'https://oss.go.id/', 'name' => 'OSS']) }}"
                                    class="service-btn">
                                    <span class="btn-icon">
                                        <img src="{{ asset('web-assets/assets/img/icon-oss.png') }}" alt="OSS">
                                    </span>
                                    <span class="btn-text">OSS</span>
                                </a>
                                <a href="{{ route('web.public-services', ['url' => 'https://sempadan.nunukankab.go.id/', 'name' => 'SEMPADAN']) }}"
                                    class="service-btn">
                                    <span class="btn-icon">
                                        <img src="{{ asset('web-assets/assets/img/icon-sempadan.png') }}"
                                            alt="SEMPADAN">
                                    </span>
                                    <span class="btn-text">SEMPADAN</span>
                                </a>
                            </div>
                        </div>
                    </div>

                    <!-- Row 3: Card 9: Layanan Kesehatan-->
                    <div class="service-card-new">
                        <div class="card-image-section">
                            <img src="{{ asset('web-assets/assets/img/public-service-card-header.png') }}"
                                alt="Layanan Kesehatan" class="card-bg-image">
                            <div class="card-overlay"></div>
                            <h3 class="card-title">Layanan Kesehatan</h3>
                        </div>
                        <div class="card-content-section">
                            <div class="service-btn-group">
                                <a href="{{ route('web.public-services', ['url' => 'https://sehati.nunukankab.go.id/user-management/auth/login', 'name' => 'SEHATI']) }}"
                                    class="service-btn">
                                    <span class="btn-icon">
                                        <img src="{{ asset('web-assets/assets/img/icon-ppid.png') }}" alt="PPID">
                                    </span>
                                    <span class="btn-text">SEHATI</span>
                                </a>
                            </div>
                        </div>
                    </div>

                    <!-- Card 10: Layanan Pengadaan Barang dan Jasa-->
                    <div class="service-card-new">
                        <div class="card-image-section">
                            <img src="{{ asset('web-assets/assets/img/public-service-card-header.png') }}"
                                alt="Layanan Kesehatan" class="card-bg-image">
                            <div class="card-overlay"></div>
                            <h3 class="card-title">Layanan Pengadaan Barang <br>dan Jasa</h3>
                        </div>
                        <div class="card-content-section">
                            <div class="service-btn-group">
                                <a href="{{ route('web.public-services', ['url' => 'https://spse.inaproc.id/nunukankab', 'name' => 'INAPROC']) }}"
                                    class="service-btn">
                                    <span class="btn-icon">
                                        <img src="{{ asset('web-assets/assets/img/icon-ppid.png') }}" alt="PPID">
                                    </span>
                                    <span class="btn-text">INAPROC</span>
                                </a>
                            </div>
                        </div>
                    </div>

                    <!-- Card 11: Layanan Pengadaan Barang dan Jasa-->
                    <div class="service-card-new">
                        <div class="card-image-section">
                            <img src="{{ asset('web-assets/assets/img/public-service-card-header.png') }}"
                                alt="Layanan Kesehatan" class="card-bg-image">
                            <div class="card-overlay"></div>
                            <h3 class="card-title">Layanan Perpustakaan</h3>
                        </div>
                        <div class="card-content-section">
                            <div class="service-btn-group">
                                <a href="{{ route('web.public-services', ['url' => 'http://layananperpus.nunukankab.go.id', 'name' => 'INLISLITE']) }}"
                                    class="service-btn">
                                    <span class="btn-icon">
                                        <img src="{{ asset('web-assets/assets/img/icon-ppid.png') }}" alt="PPID">
                                    </span>
                                    <span class="btn-text">INLISLITE</span>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- ADM Pemerintah Modal - Layanan Administrasi Pemerintah -->
    <div id="admModal" class="modal-overlay" aria-hidden="true">
        <div class="modal-content adm-modal-content">
            <button class="close-modal btn btn-sm btn-danger"
                style="position: absolute; top: 15px; right: 15px; z-index: 10;">
                <i class="bi bi-x"></i>
                <span>Keluar</span>
            </button>
            <div class="adm-modal-wrapper">
                @if (session('sso_data'))
                    <!-- SSO Data for JavaScript -->
                    <script type="application/json" id="admSsoData">{{ session('sso_data') }}</script>
                    
                    <!-- Jika sudah login dari SSO, tampilkan services modal -->
                    @include('web.components.modal.modal-adm-services')
                @else
                    <!-- Jika belum login, tampilkan login options -->
                    <!-- Left Side: Logo & Login Options -->
                    <div class="adm-left-panel">
                        <div class="adm-login-options">
                            <div class="adm-logo-container">
                                <img src="{{ asset('web-assets/assets/img/nunukan-1.png') }}" alt="Nunukan Satu Logo"
                                    class="adm-logo-img">
                            </div>
                            <a href="{{ route('web.sso-login') }}" class="adm-btn-login adm-btn-myasn">
                                <svg class="adm-btn-icon" viewBox="0 0 24 24" width="24" height="24">
                                    <path
                                        d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 3c1.66 0 3 1.34 3 3s-1.34 3-3 3-3-1.34-3-3 1.34-3 3-3zm0 14.2c-2.5 0-4.71-1.28-6-3.22.03-1.99 4-3.08 6-3.08 1.99 0 5.97 1.09 6 3.08-1.29 1.94-3.5 3.22-6 3.22z"
                                        fill="white" />
                                </svg>
                                <span>Masuk Dengan MyAsn</span>
                            </a>
                            <a href="https://mail.nunukankab.go.id/webmail/" class="adm-btn-login adm-btn-email"
                                target="_blank">
                                <svg class="adm-btn-icon" viewBox="0 0 24 24" width="24" height="24">
                                    <path
                                        d="M20 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4l-8 5-8-5V6l8 5 8-5v2z"
                                        fill="#D32F2F" />
                                </svg>
                                <span>Mail Dinas @nunukankab.go.id</span>
                            </a>
                        </div>
                    </div>

                    <!-- Right Side: Services List -->
                    <div class="adm-right-panel">
                        <!-- Layanan Naskah Dinas & Kesehatan -->
                        <div class="adm-service-section">
                            <div class="adm-service-row">
                                <div class="adm-service-label">
                                    <p>Layanan naskah dinas<br>dan kesehatan</p>
                                </div>
                                <div class="adm-service-icons">
                                    <div class="adm-icon-item"><img src="{{ asset('web-assets/assets/img/tndd.png') }}" alt="TNDD"></div>
                                    <div class="adm-icon-item"><img src="{{ asset('web-assets/assets/img/srikandi.png') }}" alt="SRIKANDI"></div>
                                    <div class="adm-icon-item"><img src="{{ asset('web-assets/assets/img/sirapel.png') }}" alt="SIRAPEL"></div>
                                </div>
                            </div>
                            <div class="adm-divider"></div>
                        </div>

                        <!-- Layanan Manajemen Kepegawaian -->
                        <div class="adm-service-section">
                            <div class="adm-service-row">
                                <div class="adm-service-label">
                                    <p>Layanan Manajemen<br>Kepegawaian</p>
                                </div>
                                <div class="adm-service-icons">
                                    <div class="adm-icon-item"><img src="{{ asset('web-assets/assets/img/bkn.png') }}" alt="BKN"></div>
                                    <div class="adm-icon-item"><img src="{{ asset('web-assets/assets/img/eanjab.png') }}" alt="eANJAB"></div>
                                </div>
                            </div>
                            <div class="adm-divider"></div>
                        </div>

                        <!-- Layanan Manajemen Perencanaan & Anggaran -->
                        <div class="adm-service-section">
                            <div class="adm-service-row">
                                <div class="adm-service-label">
                                    <p>Layanan Manajemen<br>Perencanaan dan Anggaran</p>
                                </div>
                                <div class="adm-service-icons">
                                    <div class="adm-icon-item"><img src="{{ asset('web-assets/assets/img/sipecel.png') }}" alt="SIPECEL"></div>
                                    <div class="adm-icon-item"><img src="{{ asset('web-assets/assets/img/sipd.png') }}" alt="SIPD"></div>
                                </div>
                            </div>
                            <div class="adm-divider"></div>
                        </div>

                        <!-- Layanan Manajemen Keuangan -->
                        <div class="adm-service-section">
                            <div class="adm-service-row">
                                <div class="adm-service-label">
                                    <p>Layanan Manajemen<br>Keuangan</p>
                                </div>
                                <div class="adm-service-icons">
                                    <div class="adm-icon-item"><img src="{{ asset('web-assets/assets/img/fmis.png') }}" alt="FMIS"></div>
                                </div>
                            </div>
                            <div class="adm-divider"></div>
                        </div>

                        <!-- Layanan Manajemen Kinerja -->
                        <div class="adm-service-section">
                            <div class="adm-service-row">
                                <div class="adm-service-label">
                                    <p>Layanan Manajemen<br>Kinerja</p>
                                </div>
                                <div class="adm-service-icons">
                                    <div class="adm-icon-item"><img src="{{ asset('web-assets/assets/img/epresence.png') }}" alt="e-Presence"></div>
                                    <div class="adm-icon-item"><img src="{{ asset('web-assets/assets/img/simanja.png') }}" alt="SIMANJA"></div>
                                    <div class="adm-icon-item"><img src="{{ asset('web-assets/assets/img/sepakat.png') }}" alt="SEPAKAT"></div>
                                </div>
                            </div>
                        </div>

                        <!-- Coming Soon -->
                        <div class="adm-coming-soon">
                            <h5>Coming Soon:</h5>
                            <div class="adm-upcoming-items">
                                <div class="adm-upcoming-item">
                                    <img src="{{ asset('web-assets/assets/img/tndd.png') }}" alt="TNDD">
                                    <p>Fitur Surat Perintah Perjalanan Dinas</p>
                                </div>
                                <div class="adm-upcoming-item">
                                    <img src="{{ asset('web-assets/assets/img/sirapel.png') }}" alt="SIRAPEL">
                                    <p>Fitur Notulensi Full Record</p>
                                </div>
                            </div>
                        </div>
                    </div>
                @endif
            </div>
        </div>
    </div>

    <!-- Pengaduan Popup -->
    <div id="pengaduanPopup" class="pengaduan-popup">
        <div class="pengaduan-options">
            <div class="pengaduan-option">
                <h6 class="option-title">
                    <a href="https://lapor.go.id" target="_blank">SP4N Lapor</a>
                </h6>
            </div>
            <div class="pengaduan-option">
                <h6 class="option-title">
                    <a href="https://satpolpp.nunukankab.go.id/" target="_blank">SILAPDAT</a>
                </h6>
            </div>
            <div class="pengaduan-option">
                <h6 class="option-title">
                    <a href="https://wbs.nunukankab.go.id/" target="_blank">WBS</a>
                </h6>
            </div>
            <div class="pengaduan-option">
                <h6 class="option-title">
                    <a href="https://forms.zohopublic.com/inspektoratnunukan1/form/PELAYANANKONSULTASI/formperma/zRe1jeiELo69ESPH80F4dfanVC72mD6XQS7BuBkNFY4"
                        target="_blank">Pelayanan Konsultasi</a>
                </h6>
            </div>
        </div>
    </div>

    <!-- Search Results Modal -->
    <div id="searchModal" class="modal-overlay search-modal-overlay">
        <div class="modal-content search-modal-content">
            <!-- Search Header with Input -->
            <div class="search-header">
                <input type="text" id="searchInput" class="search-input"
                    placeholder="Cari layanan, berita, atau informasi...">
                <button class="close-modal btn btn-sm btn-danger px-3" id="closeSearchModal">
                    <i class="bi bi-x"></i>
                    <span>Keluar</span>
                </button>
            </div>

            <!-- Tab Navigation -->
            <div class="search-tabs">
                <button class="search-tab active" data-tab="all">
                    <span class="tab-icon">
                        <i class="bi bi-list"></i>
                    </span>
                    <span class="tab-label">Semua</span>
                    <span class="tab-count">0</span>
                </button>
                <button class="search-tab" data-tab="publik">
                    <span class="tab-icon">
                        <i class="bi bi-info-circle"></i>
                    </span>
                    <span class="tab-label">Layanan Publik</span>
                    <span class="tab-count">0</span>
                </button>
                <button class="search-tab" data-tab="adm">
                    <span class="tab-icon">
                        <i class="bi bi-building"></i>
                    </span>
                    <span class="tab-label">Layanan ADM Pemerintah</span>
                    <span class="tab-count">0</span>
                </button>
                <button class="search-tab" data-tab="berita">
                    <span class="tab-icon">
                        <i class="bi bi-newspaper"></i>
                    </span>
                    <span class="tab-label">Berita</span>
                    <span class="tab-count">0</span>
                </button>
                <button class="search-tab" data-tab="data-informasi">
                    <span class="tab-icon">
                        <i class="bi bi-database"></i>
                    </span>
                    <span class="tab-label">Data & Informasi</span>
                    <span class="tab-count">0</span>
                </button>
            </div>

            <!-- Search Results Content -->
            <div class="search-results-body">
                <!-- Tab: Semua -->
                <div class="search-tab-content active" id="tab-all">
                    <!-- Will be populated by JavaScript -->
                </div>

                <!-- Tab: Layanan Publik -->
                <div class="search-tab-content" id="tab-publik">
                    <!-- Will be populated by JavaScript -->
                </div>

                <!-- Tab: Layanan ADM Pemerintah -->
                <div class="search-tab-content" id="tab-adm">
                    <!-- Will be populated by JavaScript -->
                </div>

                <!-- Tab: Berita -->
                <div class="search-tab-content" id="tab-berita">
                    <!-- Will be populated by JavaScript -->
                </div>

                <!-- Tab: Data & Informasi -->
                <div class="search-tab-content" id="tab-data-informasi">
                    <!-- Will be populated by JavaScript -->
                </div>
            </div>
        </div>
    </div>



    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="{{ asset('web-assets/script.js') }}"></script>
    <script src="{{ asset('web-assets/search.js') }}"></script>
</body>

</html>