<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mall Data & Informasi - Nunukan Satu</title>

    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;600;700&display=swap" rel="stylesheet">

    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">    
    <!-- Custom CSS -->
    <link rel="stylesheet" href="{{ asset('web-assets/style.css') }}">
    <!-- Public Services CSS for Search Modal -->
    <link rel="stylesheet" href="{{ asset('web-assets/public-services.css') }}">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Roboto', sans-serif;
            color: #212121;
        }

        /* Header/Navbar */
        .mall-header {
            background-color: #D32F2F;
            padding: 12px 40px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .mall-logo {
            height: 50px;
        }

        .mall-nav {
            display: flex;
            align-items: center;
            gap: 32px;
            flex: 1;
            margin-left: 40px;
        }

        .mall-nav a {
            color: white;
            text-decoration: none;
            font-size: 14px;
            font-weight: 500;
            position: relative;
            padding-bottom: 4px;
            transition: all 0.3s ease;
        }

        .mall-nav a:after {
            content: '▼';
            font-size: 8px;
            margin-left: 4px;
        }

        .mall-nav a:hover {
            opacity: 0.8;
        }

        .mall-search-btn {
            background: none;
            border: none;
            color: white;
            font-size: 20px;
            cursor: pointer;
            padding: 0;
        }

        /* Main Content Area */
        .mall-container {
            min-height: 100vh;
            background: linear-gradient(135deg, #D32F2F 0%, #8E0000 100%);
            padding: 60px 40px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .mall-cards-wrapper {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 32px;
            max-width: 1200px;
            width: 100%;
        }

        .mall-card {
            background: white;
            border-radius: 20px;
            overflow: hidden;
            box-shadow: 0 8px 24px rgba(0, 0, 0, 0.2);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            cursor: pointer;
        }

        .mall-card:hover {
            transform: translateY(-8px);
            box-shadow: 0 12px 32px rgba(0, 0, 0, 0.3);
        }

        .mall-card-image {
            width: 100%;
            height: 280px;
            overflow: hidden;
            position: relative;
        }

        .mall-card-image img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .mall-card-title {
            padding: 24px;
            text-align: center;
            font-size: 20px;
            font-weight: 700;
            color: #212121;
        }

        .mall-card-pattern {
            width: 100%;
            height: 80px;
            background: repeating-linear-gradient(45deg,
                    #f5f5f5,
                    #f5f5f5 10px,
                    #eeeeee 10px,
                    #eeeeee 20px);
            opacity: 0.5;
        }

        /* Bottom Navigation */
        .mall-bottom-nav {
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            background: white;
            border-top: 3px solid #D32F2F;
            padding: 16px 40px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            box-shadow: 0 -2px 8px rgba(0, 0, 0, 0.1);
            height: 100px;
        }

        .mall-logo-section {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .mall-logo-section img {
            height: 40px;
        }

        .mall-logo-text {
            font-size: 12px;
            font-weight: 600;
            color: #212121;
        }

        .mall-nav-center {
            display: flex;
            align-items: center;
            gap: 12px;
            flex: 1;
            justify-content: center;
            min-width: 0;
            margin: 0 60px;
        }

        .mall-nav-items {
            display: flex;
            align-items: center;
            gap: 12px;
            overflow-x: auto;
            scroll-behavior: smooth;
            -ms-overflow-style: none;
            /* IE and Edge */
            scrollbar-width: none;
            /* Firefox */
            padding: 4px 0;
            width: 100%;
        }

        .mall-nav-items::-webkit-scrollbar {
            display: none;
            /* Chrome, Safari and Opera */
        }

        .mall-search-box {
            background: #D8423F;
            border: none;
            color: white;
            padding: 10px 20px;
            border-radius: 8px;
            width: 120px;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 6px;
            cursor: pointer;
            transition: background 0.3s ease;
        }

        .mall-search-box:hover {
            background: #B71C1C;
        }

        .mall-search-box i {
            font-size: 14px;
        }

        .mall-search-box span {
            font-size: 12px;
            font-weight: 500;
            color: white;
        }

        .mall-arrow-btn {
            background: white;
            border: 2px solid #D8423F;
            color: #D8423F;
            width: 40px;
            height: 40px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: background 0.3s ease, color 0.3s ease;
            flex-shrink: 0;
            font-size: 18px;
        }

        .mall-arrow-btn:hover {
            background: #D8423F;
            color: white;
        }

        .mall-action-btn {
            background: #D8423F;
            border: none;
            color: white;
            padding: 8px 16px 8px 8px;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: flex-start;
            gap: 10px;
            cursor: pointer;
            font-size: 14px;
            font-weight: 500;
            transition: background 0.3s ease;
            white-space: nowrap;
            flex-shrink: 0;
            min-width: 240px;
        }

        .mall-action-btn.active {
            background: #A6160F;
        }

        .mall-action-btn:hover {
            background: #A6160F;
        }

        .mall-action-btn .icon-circle {
            background: white;
            color: #D8423F;
            width: 32px;
            height: 32px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 14px;
        }

        .mall-action-btn.active .icon-circle {
            color: #A6160F;
        }

        /* Responsive Design */
        @media (max-width: 1024px) {
            .mall-cards-wrapper {
                grid-template-columns: repeat(2, 1fr);
                gap: 24px;
            }
        }

        @media (max-width: 768px) {
            .mall-header {
                padding: 12px 20px;
                flex-wrap: wrap;
            }

            .mall-nav {
                display: none;
            }

            .mall-container {
                padding: 40px 20px;
                padding-bottom: 140px;
            }

            .mall-cards-wrapper {
                grid-template-columns: 1fr;
                gap: 20px;
            }

            .mall-card-image {
                height: 200px;
            }

            .mall-bottom-nav {
                padding: 12px 20px;
                flex-wrap: wrap;
                gap: 12px;
                height: auto;
            }

            .mall-nav-center {
                width: 100%;
                order: 3;
                margin: 0 60px;
            }
        }

        /* Iframe Container Styles */
        .iframe-section {
            width: 100%;
            height: calc(100vh - 100px);
            display: none;
            background: #f5f5f5;
        }

        .iframe-section.active {
            display: block;
        }

        .iframe-section iframe {
            width: 100%;
            height: 100%;
            border: none;
        }

        @media (max-width: 768px) {
            .iframe-section {
                height: calc(100vh - 130px);
            }
        }

        /* Coming Soon Section */
        .coming-soon-section {
            width: 100%;
            height: calc(100vh - 100px);
            display: none;
            position: relative;
            overflow: hidden;
            background-color: #f5f5f5;
        }

        .coming-soon-section.active {
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .coming-soon-bg {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            object-fit: cover;
            z-index: 1;
        }

        .coming-soon-icon {
            position: relative;
            z-index: 2;
            max-width: 80%;
            max-height: 80%;
            object-fit: contain;
        }

        @media (max-width: 768px) {
            .coming-soon-section {
                height: calc(100vh - 130px);
            }
        }
    </style>
</head>

<body>
    <!-- Full Page Modal for displaying content -->
    <div class="modal fade" id="fullPageModal" tabindex="-1" role="dialog" aria-labelledby="fullPageModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-fullscreen" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="fullPageModalLabel">Loading...</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body p-0">
                    <iframe id="appIframe" style="width: 100%; height: calc(100vh - 150px); border: none;" src="" frameborder="0"></iframe>
                </div>
            </div>
        </div>
    </div>

    <!-- Hidden sections for coming soon content -->
    <div id="profilDaerah" class="iframe-section active" style="display: none;"></div>
    <div id="satudata" class="iframe-section" style="display: none;"></div>
    <div id="berita" class="iframe-section" style="display: none;"></div>
    <div id="jdih" class="iframe-section" style="display: none;"></div>

    <!-- Coming Soon Section -->
    <div id="comingSoon" class="coming-soon-section iframe-section" style="display: none;">
        <img src="{{ asset('web-assets/assets/img/coming-soon-bg.jpg') }}" class="coming-soon-bg" alt="Coming Soon Background">
        <img src="{{ asset('web-assets/assets/img/coming-soon-icon.png') }}" class="coming-soon-icon" alt="Coming Soon Icon">
    </div>

    <!-- Bottom Navigation -->
    <nav class="mall-bottom-nav">
        <div class="mall-logo-section">
            <a href="{{ route('web.home') }}">
                <img src="{{ asset('web-assets/assets/img/Nunukansatu Logo1 2.png') }}" alt="Nunukan Satu Logo">
            </a>
        </div>

        <div class="mall-nav-center">
            <button id="searchBtn" class="mall-search-box">
                <i class="bi bi-search"></i>
                <span>Search</span>
            </button>

            <button class="mall-arrow-btn" id="scrollLeftBtn">
                <i class="bi bi-chevron-left"></i>
            </button>

            <div class="mall-nav-items" id="navItemsContainer">
                <button class="mall-action-btn active" id="btnProfilDaerah">
                    <span class="icon-circle">
                        <i class="bi bi-building"></i>
                    </span>
                    Profil Daerah
                </button>

                <button class="mall-action-btn" id="btnSatuData">
                    <span class="icon-circle">
                        <i class="bi bi-server"></i>
                    </span>
                    Satu Data
                </button>

                <button class="mall-action-btn" id="btnPengumuman">
                    <span class="icon-circle">
                        <i class="bi bi-bell"></i>
                    </span>
                    Pengumuman
                </button>

                <button class="mall-action-btn" id="btnJDIH">
                    <span class="icon-circle">
                        <i class="bi bi-database"></i>
                    </span>
                    JDIH
                </button>

                <button class="mall-action-btn" id="btnBerita">
                    <span class="icon-circle">
                        <i class="bi bi-newspaper"></i>
                    </span>
                    Berita
                </button>

                <button class="mall-action-btn" id="btnProyekStrategis">
                    <span class="icon-circle">
                        <i class="bi bi-diagram-3"></i>
                    </span>
                    Proyek Strategis Daerah
                </button>

                <button class="mall-action-btn" id="btnTransparansiAnggaran">
                    <span class="icon-circle">
                        <i class="bi bi-cash-coin"></i>
                    </span>
                    Transparansi Anggaran
                </button>

                <button class="mall-action-btn" id="btnInformasiADM">
                    <span class="icon-circle">
                        <i class="bi bi-archive"></i>
                    </span>
                    Informasi ADM Pemerintah
                </button>

                <button class="mall-action-btn" id="btnInformasiPublik">
                    <span class="icon-circle">
                        <i class="bi bi-bookshelf"></i>
                    </span>
                    Informasi Publik
                </button>
            </div>

            <button class="mall-arrow-btn" id="scrollRightBtn">
                <i class="bi bi-chevron-right"></i>
            </button>
        </div>
    </nav>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="{{ asset('web-assets/search-modal-component.js') }}"></script>
    <script src="{{ asset('web-assets/search.js') }}"></script>

    <script>
        // Map menu items to their titles and URLs
        const menuConfig = {
            'profil': {
                title: 'Profil Daerah',
                url: 'https://profil.nunukankab.go.id/'
            },
            'satudata': {
                title: 'Satu Data',
                url: 'https://satudata.nunukankab.go.id/'
            },
            'pengumuman': {
                title: 'Pengumuman',
                url: null // Coming soon
            },
            'jdih': {
                title: 'JDIH',
                url: 'https://jdih.nunukankab.go.id/'
            },
            'berita': {
                title: 'Berita',
                url: 'https://www.berita.nunukankab.go.id/'
            },
            'proyek-strategis': {
                title: 'Proyek Strategis Daerah',
                url: null // Coming soon
            },
            'transparansi-anggaran': {
                title: 'Transparansi Anggaran',
                url: null // Coming soon
            },
            'informasi-adm': {
                title: 'Informasi ADM Pemerintah',
                url: null // Coming soon
            },
            'informasi-publik': {
                title: 'Informasi Publik',
                url: null // Coming soon
            }
        };

        function showMenuContent(menuKey) {
            const config = menuConfig[menuKey];
            if (!config) return;

            const modalLabel = document.getElementById('fullPageModalLabel');
            const appIframe = document.getElementById('appIframe');
            const modal = document.getElementById('fullPageModal');

            if (config.url) {
                // Show iframe in modal
                modalLabel.textContent = config.title;
                appIframe.src = config.url;
                appIframe.style.display = 'block';
                
                // Hide coming soon content
                appIframe.parentElement.querySelector('.coming-soon-bg')?.style.display = 'none';
                appIframe.parentElement.querySelector('.coming-soon-icon')?.style.display = 'none';
                
                // Show modal
                const bootstrapModal = new bootstrap.Modal(modal);
                bootstrapModal.show();
            } else {
                // Show coming soon
                modalLabel.textContent = config.title + ' - Coming Soon';
                appIframe.style.display = 'none';
                
                const comingSoonBg = document.createElement('img');
                comingSoonBg.src = '{{ asset("web-assets/assets/img/coming-soon-bg.jpg") }}';
                comingSoonBg.className = 'coming-soon-bg';
                comingSoonBg.alt = 'Coming Soon Background';
                
                const comingSoonIcon = document.createElement('img');
                comingSoonIcon.src = '{{ asset("web-assets/assets/img/coming-soon-icon.png") }}';
                comingSoonIcon.className = 'coming-soon-icon';
                comingSoonIcon.alt = 'Coming Soon Icon';
                
                const iframeContainer = appIframe.parentElement;
                iframeContainer.innerHTML = '';
                iframeContainer.appendChild(comingSoonBg);
                iframeContainer.appendChild(comingSoonIcon);
                iframeContainer.style.display = 'flex';
                iframeContainer.style.alignItems = 'center';
                iframeContainer.style.justifyContent = 'center';
                iframeContainer.style.minHeight = 'calc(100vh - 150px)';
                
                const bootstrapModal = new bootstrap.Modal(modal);
                bootstrapModal.show();
            }
        }

        document.addEventListener('DOMContentLoaded', function () {
            const container = document.getElementById('navItemsContainer');
            const scrollLeftBtn = document.getElementById('scrollLeftBtn');
            const scrollRightBtn = document.getElementById('scrollRightBtn');
            const scrollAmount = 200;

            if (scrollLeftBtn && scrollRightBtn && container) {
                scrollLeftBtn.addEventListener('click', () => {
                    container.scrollBy({ left: -scrollAmount, behavior: 'smooth' });
                });

                scrollRightBtn.addEventListener('click', () => {
                    container.scrollBy({ left: scrollAmount, behavior: 'smooth' });
                });
            }

            // Menu button click handlers
            const btnProfilDaerah = document.getElementById('btnProfilDaerah');
            const btnSatuData = document.getElementById('btnSatuData');
            const btnBerita = document.getElementById('btnBerita');
            const btnJDIH = document.getElementById('btnJDIH');
            const btnPengumuman = document.getElementById('btnPengumuman');
            const btnProyekStrategis = document.getElementById('btnProyekStrategis');
            const btnTransparansiAnggaran = document.getElementById('btnTransparansiAnggaran');
            const btnInformasiADM = document.getElementById('btnInformasiADM');
            const btnInformasiPublik = document.getElementById('btnInformasiPublik');

            const allNavBtns = document.querySelectorAll('.mall-action-btn');

            function updateActiveButton(clickedBtn) {
                allNavBtns.forEach(btn => btn.classList.remove('active'));
                if (clickedBtn) clickedBtn.classList.add('active');
            }

            // Attach click handlers
            if (btnProfilDaerah) {
                btnProfilDaerah.addEventListener('click', function () {
                    updateActiveButton(btnProfilDaerah);
                    showMenuContent('profil');
                });
            }

            if (btnSatuData) {
                btnSatuData.addEventListener('click', function () {
                    updateActiveButton(btnSatuData);
                    showMenuContent('satudata');
                });
            }

            if (btnBerita) {
                btnBerita.addEventListener('click', function () {
                    updateActiveButton(btnBerita);
                    showMenuContent('berita');
                });
            }

            if (btnJDIH) {
                btnJDIH.addEventListener('click', function () {
                    updateActiveButton(btnJDIH);
                    showMenuContent('jdih');
                });
            }

            if (btnPengumuman) {
                btnPengumuman.addEventListener('click', function () {
                    updateActiveButton(btnPengumuman);
                    showMenuContent('pengumuman');
                });
            }

            if (btnProyekStrategis) {
                btnProyekStrategis.addEventListener('click', function () {
                    updateActiveButton(btnProyekStrategis);
                    showMenuContent('proyek-strategis');
                });
            }

            if (btnTransparansiAnggaran) {
                btnTransparansiAnggaran.addEventListener('click', function () {
                    updateActiveButton(btnTransparansiAnggaran);
                    showMenuContent('transparansi-anggaran');
                });
            }

            if (btnInformasiADM) {
                btnInformasiADM.addEventListener('click', function () {
                    updateActiveButton(btnInformasiADM);
                    showMenuContent('informasi-adm');
                });
            }

            if (btnInformasiPublik) {
                btnInformasiPublik.addEventListener('click', function () {
                    updateActiveButton(btnInformasiPublik);
                    showMenuContent('informasi-publik');
                });
            }

            // Deep link: read ?menu= param and activate the corresponding menu
            const urlParams = new URLSearchParams(window.location.search);
            const menuParam = urlParams.get('menu');
            if (menuParam) {
                const btnMap = {
                    'profil': btnProfilDaerah,
                    'satudata': btnSatuData,
                    'pengumuman': btnPengumuman,
                    'jdih': btnJDIH,
                    'berita': btnBerita,
                    'proyek-strategis': btnProyekStrategis,
                    'transparansi-anggaran': btnTransparansiAnggaran,
                    'informasi-adm': btnInformasiADM,
                    'informasi-publik': btnInformasiPublik
                };
                const target = btnMap[menuParam];
                if (target) {
                    updateActiveButton(target);
                    showMenuContent(menuParam);
                    target.scrollIntoView({ behavior: 'smooth', block: 'nearest', inline: 'center' });
                }
            } else {
                // Default: show first menu (Profil Daerah)
                updateActiveButton(btnProfilDaerah);
                showMenuContent('profil');
            }
        });
    </script>
</body>

</html>