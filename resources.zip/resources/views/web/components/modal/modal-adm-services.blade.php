@push('styles')
<style>
    .adm-modal-header-enhanced {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 20px;
        border-bottom: 2px solid #f0f0f0;
        background: #f9f9f9;
    }

    .adm-user-info {
        display: flex;
        align-items: center;
        gap: 10px;
    }

    .adm-user-info h4 {
        margin: 0;
        font-size: 16px;
        font-weight: 600;
        color: #333;
    }

    .adm-user-info .user-role {
        font-size: 12px;
        color: #666;
    }

    .service-btn[style*="display: none"] {
        display: none !important;
    }

    .adm-no-access-message {
        padding: 20px;
        text-align: center;
        color: #999;
        display: none;
    }

    .modal-body-adm.no-services-available .service-grid-adm {
        display: none;
    }

    .modal-body-adm.no-services-available .adm-no-access-message {
        display: block;
    }
</style>
@endpush

<!-- ADM Pemerintah Modal - Layanan Administrasi Pemerintah (Enhanced) -->
<div id="admModal" class="modal-overlay" aria-hidden="true">
    <div class="modal-content modal-adm-services">
        <div class="adm-modal-header-enhanced">
            <div class="adm-user-info">
                <div>
                    <h4>Selamat datang, <span id="admUserName">Pengguna</span></h4>
                    <div class="user-role"><span id="admUserRole">Jabatan: -</span></div>
                </div>
            </div>
            <div style="display: flex; gap: 10px;">
                <button class="btn btn-sm btn-danger" id="btnLogoutAdm" title="Keluar">
                    <i class="bi bi-box-arrow-right"></i> Keluar
                </button>
                <button class="close-modal btn btn-sm btn-secondary px-3">
                    <i class="bi bi-x"></i> Tutup
                </button>
            </div>
        </div>
        <div class="modal-header-adm" style="border-bottom: 2px solid #ddd;">
            <div class="header-title-section">
                <h2>LAYANAN ADMINISTRASI PEMERINTAH</h2>
                <div class="header-underline"></div>
            </div>
        </div>
        <div class="modal-body-adm">
            <div class="adm-no-access-message">
                <p>Anda tidak memiliki akses ke layanan apapun sesuai dengan jabatan Anda.</p>
            </div>
            <div class="service-grid-adm">
                <!-- Card 1: Layanan Naskah Dinas & Kearsipan -->
                <div class="service-card-adm">
                    <div class="card-image-section">
                        <img src="{{ asset('web-assets/assets/img/public-service-card-header.png') }}" alt="Layanan Naskah Dinas & Kearsipan"
                            class="card-bg-image">
                        <div class="card-overlay"></div>
                        <h3 class="card-title">Layanan Naskah Dinas & Kearsipan</h3>
                    </div>
                    <div class="card-content-section">
                        <div class="service-btn-group">
                            <a href="#" class="service-btn adm-app-link" x-app-role="*" x-app-type="iframe" x-app-target="https://tndd.nunukankab.go.id/login/auth_sso" x-app-name="TATA NASKAH DINAS DIGITAL">
                                <div class="btn-icon">
                                    <img src="{{ asset('web-assets/assets/img/tndd.png') }}" alt="TNDD">
                                </div>
                                <span class="btn-text">TATA NASKAH DINAS DIGITAL</span>
                            </a>
                            <a href="#" class="service-btn adm-app-link" x-app-role="*" x-app-type="direct" x-app-target="https://srikandi.arsip.go.id/" x-app-name="SRIKANDI">
                                <div class="btn-icon">
                                    <img src="{{ asset('web-assets/assets/img/srikandi.png') }}" alt="SRIKANDI">
                                </div>
                                <span class="btn-text">SRIKANDI</span>
                            </a>
                            <a href="#" class="service-btn adm-app-link" x-app-role="kepala dinas;kepala bidang;kepala satuan;sekretaris;kepala bagian" x-app-type="iframe" x-app-target="https://rapat.nunukankab.go.id/sso.php" x-app-name="SIRAPEL">
                                <div class="btn-icon">
                                    <img src="{{ asset('web-assets/assets/img/sirapel.png') }}" alt="SIRAPEL">
                                </div>
                                <span class="btn-text">SIRAPEL</span>
                            </a>
                        </div>
                    </div>
                </div>

                <!-- Card 2: Layanan Manajemen Kepegawaian -->
                <div class="service-card-adm">
                    <div class="card-image-section">
                        <img src="{{ asset('web-assets/assets/img/public-service-card-header.png') }}" alt="Layanan Manajemen Kepegawaian"
                            class="card-bg-image">
                        <div class="card-overlay"></div>
                        <h3 class="card-title">Layanan Manajemen Kepegawaian</h3>
                    </div>
                    <div class="card-content-section">
                        <div class="service-btn-group">
                            <a href="#" class="service-btn adm-app-link" x-app-role="*" x-app-type="direct" x-app-target="https://siasn-instansi.bkn.go.id" x-app-name="BKN">
                                <div class="btn-icon">
                                    <img src="{{ asset('web-assets/assets/img/bkn.png') }}" alt="BKN">
                                </div>
                                <span class="btn-text">BKN</span>
                            </a>
                            <a href="#" class="service-btn adm-app-link" x-app-role="kepala dinas" x-app-type="iframe" x-app-target="https://eanjab.nunukankab.go.id/sso.php" x-app-name="ANJAB">
                                <div class="btn-icon">
                                    <img src="{{ asset('web-assets/assets/img/eanjab.png') }}" alt="ANJAB">
                                </div>
                                <span class="btn-text">ANJAB</span>
                            </a>
                        </div>
                    </div>
                </div>

                <!-- Card 3: Layanan Manajemen Perencanaan & Anggaran -->
                <div class="service-card-adm">
                    <div class="card-image-section">
                        <img src="{{ asset('web-assets/assets/img/public-service-card-header.png') }}"
                            alt="Layanan Manajemen Perencanaan & Anggaran" class="card-bg-image">
                        <div class="card-overlay"></div>
                        <h3 class="card-title">Layanan Manajemen Perencanaan & Anggaran</h3>
                    </div>
                    <div class="card-content-section">
                        <div class="service-btn-group">
                            <a href="#" class="service-btn adm-app-link" x-app-role="kepala dinas;kepala bidang;sekretaris" x-app-type="iframe" x-app-target="https://sipecel.nunukankab.go.id/login/auth_sso" x-app-name="SIPECEL">
                                <div class="btn-icon">
                                    <img src="{{ asset('web-assets/assets/img/sipecel.png') }}" alt="SIPECEL">
                                </div>
                                <span class="btn-text">SIPECEL</span>
                            </a>
                            <a href="#" class="service-btn adm-app-link" x-app-role="kepala" x-app-type="direct" x-app-target="https://sipd-ri.kemendagri.go.id" x-app-name="SIPD">
                                <div class="btn-icon">
                                    <img src="{{ asset('web-assets/assets/img/sipd.png') }}" alt="SIPD">
                                </div>
                                <span class="btn-text">SIPD</span>
                            </a>
                        </div>
                    </div>
                </div>

                <!-- Card 4: Layanan Manajemen Keuangan -->
                <div class="service-card-adm">
                    <div class="card-image-section">
                        <img src="{{ asset('web-assets/assets/img/public-service-card-header.png') }}" alt="Layanan Manajemen Keuangan"
                            class="card-bg-image">
                        <div class="card-overlay"></div>
                        <h3 class="card-title">Layanan Manajemen Keuangan</h3>
                    </div>
                    <div class="card-content-section">
                        <div class="service-btn-group">
                            <a href="#" class="service-btn adm-app-link" x-app-role="bendahara" x-app-type="iframe" x-app-target="https://nunukankab.fmis.id/2023" x-app-name="FMIS">
                                <div class="btn-icon">
                                    <img src="{{ asset('web-assets/assets/img/fmis.png') }}" alt="FMIS">
                                </div>
                                <span class="btn-text">FMIS</span>
                            </a>
                        </div>
                    </div>
                </div>

                <!-- Card 5: Layanan Manajemen Kinerja -->
                <div class="service-card-adm">
                    <div class="card-image-section">
                        <img src="{{ asset('web-assets/assets/img/public-service-card-header.png') }}" alt="Layanan Manajemen Kinerja"
                            class="card-bg-image">
                        <div class="card-overlay"></div>
                        <h3 class="card-title">Layanan Manajemen Kinerja</h3>
                    </div>
                    <div class="card-content-section">
                        <div class="service-btn-group">
                            <a href="#" class="service-btn adm-app-link" x-app-role="*" x-app-type="epresence" x-app-target="https://ekinerja.nunukankab.go.id/presence/sso.php" x-app-name="E-PRESENCE">
                                <div class="btn-icon">
                                    <img src="{{ asset('web-assets/assets/img/epresence.png') }}" alt="E-PRESENCE">
                                </div>
                                <span class="btn-text">E-PRESENCE</span>
                            </a>
                            <a href="#" class="service-btn adm-app-link" x-app-role="*" x-app-type="iframe" x-app-target="https://ekinerja.nunukankab.go.id/login/sso.php" x-app-name="SIMANJA">
                                <div class="btn-icon">
                                    <img src="{{ asset('web-assets/assets/img/simanja.png') }}" alt="SIMANJA">
                                </div>
                                <span class="btn-text">SIMANJA</span>
                            </a>
                            <a href="#" class="service-btn adm-app-link" x-app-role="*" x-app-type="iframe" x-app-target="https://sepakat.nunukankab.go.id/auth_sso" x-app-name="SEPAKAT">
                                <div class="btn-icon">
                                    <img src="{{ asset('web-assets/assets/img/sepakat.png') }}" alt="SEPAKAT">
                                </div>
                                <span class="btn-text">SEPAKAT</span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Full Page Modal for Iframe Apps -->
<div id="fullPageAdmModal" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true" style="z-index: 9999;">
    <div class="modal-dialog modal-fullscreen" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="fullPageAdmModalLabel">Loading...</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body p-0">
                <iframe id="appAdmIframe" style="width: 100%; height: 100%; border: none;"></iframe>
            </div>
        </div>
    </div>
</div>

@push('scripts')
<script type="text/javascript">
document.addEventListener('DOMContentLoaded', function() {
    // Initialize ADM Modal with user info
    initializeAdmModal();
});

function initializeAdmModal() {
    // Get SSO data from session (populated by Blade in home.blade.php)
    const ssoDataElement = document.getElementById('admSsoData');
    if (!ssoDataElement) {
        console.warn('SSO data not found in page');
        return;
    }

    const ssoData = JSON.parse(ssoDataElement.textContent);
    const accessToken = ssoData.access_token;
    const jabatan = ssoData.jabatan || '';

    // Store in localStorage for easy access
    localStorage.setItem('admAccessToken', accessToken);
    localStorage.setItem('admJabatan', jabatan);

    // Apply role filtering when modal is shown
    const admModal = document.getElementById('admModal');
    admModal.addEventListener('show', applyAdmRoleFiltering);
    
    // Set user display name
    setupAdmUserDisplay();

    // Setup app link handlers
    setupAdmAppLinkHandlers(accessToken);

    // Setup logout button
    setupAdmLogoutButton();
}

function setupAdmUserDisplay() {
    const jabatan = localStorage.getItem('admJabatan') || 'Pengguna';
    document.getElementById('admUserName').textContent = jabatan.split(' ')[0] || 'Pengguna';
    document.getElementById('admUserRole').textContent = 'Jabatan: ' + jabatan;
}

function applyAdmRoleFiltering() {
    const jabatanString = (localStorage.getItem('admJabatan') || '').toLowerCase();
    const appLinks = document.querySelectorAll('.adm-app-link');
    let visibleCount = 0;

    appLinks.forEach(link => {
        const requiredRole = link.getAttribute('x-app-role') || '*';
        
        if (requiredRole === '*') {
            link.style.display = '';
            visibleCount++;
        } else {
            const roles = requiredRole.split(';');
            let hasRole = false;
            
            for (let role of roles) {
                if (jabatanString.includes(role.trim())) {
                    hasRole = true;
                    break;
                }
            }
            
            link.style.display = hasRole ? '' : 'none';
            if (hasRole) visibleCount++;
        }
    });

    // Show/hide no access message
    const modalBody = document.querySelector('.modal-body-adm');
    if (visibleCount === 0) {
        modalBody.classList.add('no-services-available');
    } else {
        modalBody.classList.remove('no-services-available');
    }

    console.log(`ADM Services: ${visibleCount} services available for role: ${jabatanString}`);
}

function setupAdmAppLinkHandlers(accessToken) {
    const appLinks = document.querySelectorAll('.adm-app-link');
    
    appLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            
            const appType = this.getAttribute('x-app-type');
            const appTarget = this.getAttribute('x-app-target');
            const appName = this.getAttribute('x-app-name');

            if (!appTarget) return;

            if (appType === 'iframe') {
                openAdmAppInIframe(appTarget, appName, accessToken);
            } else if (appType === 'epresence') {
                window.open(appTarget + '?access_token=' + accessToken, '_blank');
            } else if (appType === 'direct') {
                window.open(appTarget, '_blank');
            }
        });
    });
}

function openAdmAppInIframe(appTarget, appName, accessToken) {
    const modalLabel = document.getElementById('fullPageAdmModalLabel');
    const iframe = document.getElementById('appAdmIframe');
    
    modalLabel.textContent = appName;
    iframe.src = appTarget + '?access_token=' + accessToken;
    
    const modal = new bootstrap.Modal(document.getElementById('fullPageAdmModal'));
    modal.show();
}

function setupAdmLogoutButton() {
    const logoutBtn = document.getElementById('btnLogoutAdm');
    if (!logoutBtn) return;

    logoutBtn.addEventListener('click', function() {
        // Clear localStorage
        localStorage.removeItem('admAccessToken');
        localStorage.removeItem('admJabatan');
        localStorage.removeItem('sso_modal_shown');
        
        // Redirect to SSO logout
        window.location.href = '{{ route("web.sso-logout") }}';
    });
}
</script>
@endpush